<template>
  <div id="wrap">
    <nav>
      <div id="navbox">
        <div id="leftarea">
          <button id="category">
            <img
              src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='%23575757' d='M4 18h16c.55 0 1-.45 1-1s-.45-1-1-1H4c-.55 0-1 .45-1 1s.45 1 1 1m0-5h16c.55 0 1-.45 1-1s-.45-1-1-1H4c-.55 0-1 .45-1 1s.45 1 1 1M3 7c0 .55.45 1 1 1h16c.55 0 1-.45 1-1s-.45-1-1-1H4c-.55 0-1 .45-1 1'/%3E%3C/svg%3E"
              width="20px"
              height="20px"
            />
          </button>

          <button id="search">
            <img
              src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='%23575757' d='m19.6 21l-6.3-6.3q-.75.6-1.725.95T9.5 16q-2.725 0-4.612-1.888T3 9.5t1.888-4.612T9.5 3t4.613 1.888T16 9.5q0 1.1-.35 2.075T14.7 13.3l6.3 6.3zM9.5 14q1.875 0 3.188-1.312T14 9.5t-1.312-3.187T9.5 5T6.313 6.313T5 9.5t1.313 3.188T9.5 14'/%3E%3C/svg%3E"
              width="20px"
              height="20px"
            />
          </button>
        </div>
        <RouterLink to="/" id="logo">PersonalHealth</RouterLink>

        <div id="rightarea">
          <div id="buttonwrap">
            <RouterLink to="/complain" id="complain">고객센터</RouterLink>
            <RouterLink to="/preview" id="logout">로그아웃</RouterLink>
          </div>

          <button id="profile"><img src="#" /></button>
        </div>
      </div>
    </nav>
  </div>
</template>

<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<style scoped>
nav {
  position: relative;
  width: 100vw;
  min-width: 960px;
  height: 60px;
  margin: 0 auto;
}

#navbox {
  margin: 0 auto;
  position: relative;
  width: 100vw;
  max-width: 1600px;
  min-width: 960px;
  height: 60px;
}

#leftarea {
  width: 85px;
  height: 60px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;

  position: absolute;
  left: 20px;
  top: 0;
}

#category {
  background-color: white;
  width: 32px;
  height: 32px;
  border: none;
  border-radius: 7px;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  margin-right: 15px;
}
#category:hover {
  transform: scale(1.15);
  transition: transform 0.2s linear;
  text-decoration-line: underline;
}

#category:not(:hover) {
  transition: transform 0.2s linear;
}

#search {
  background-color: white;
  width: 32px;
  height: 32px;
  border: none;
  border-radius: 7px;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
}

#search:hover {
  transform: scale(1.15);
  transition: transform 0.2s linear;
  text-decoration-line: underline;
}

#search:not(:hover) {
  transition: transform 0.2s linear;
}

#logo {
  display: inline-block;
  font-size: 1.4rem;
  font-weight: 900;
  font-family: 'Noto Sans KR';
  background: linear-gradient(283.17deg, #36b2ff 25.32%, #42d665 74.68%);
  color: transparent;
  -webkit-background-clip: text;

  position: absolute;
  left: 50%;
  top: 12%;
  transform: translate(-50%);
}

#rightarea {
  width: 180px;
  height: 60px;
  position: absolute;
  right: 20px;
  top: 0;

  display: flex;
  justify-content: center;
  align-items: center;
}

#buttonwrap {
  display: flex;
  justify-content: space-between;
  margin-right: 15px;
}

#complain {
  border: none;
  background-color: transparent;
  font-size: 0.8rem;
  font-weight: 500;
  font-family: 'Noto Sans KR';
  color: #575757;
  margin-right: 15px;
}

#logout {
  border: none;
  background-color: transparent;
  font-size: 0.8rem;
  font-weight: 500;
  font-family: 'Noto Sans KR';
  color: #575757;
}

#profile {
  background-color: white;
  width: 32px;
  height: 32px;
  border: none;
  border-radius: 7px;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
}

#complain:hover {
  transform: scale(1.05);
  transition: transform 0.2s linear;
  text-decoration-line: underline;
}

#complain:not(:hover) {
  transition: transform 0.2s linear;
}

#logout:hover {
  transform: scale(1.05);
  transition: transform 0.2s linear;
  text-decoration-line: underline;
}

#logout:not(:hover) {
  transition: transform 0.2s linear;
}

#profile:hover {
  transform: scale(1.15);
  transition: transform 0.2s linear;
  text-decoration-line: underline;
}

#profile:not(:hover) {
  transition: transform 0.2s linear;
}
</style>
