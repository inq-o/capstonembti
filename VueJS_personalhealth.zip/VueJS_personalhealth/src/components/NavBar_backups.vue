<template>
  <div id="wrap">
    <nav>
      <RouterLink to="/" id="logo">PersonalHealth</RouterLink>
      <div id="wrap01" v-show="!modalCheck">
        <div id="profile">
          <button id="prop_img" @click="modalOpen()">
            <img src="#" />
          </button>
          <div id="prop_name"><p>Admin</p></div>
        </div>

        <div id="searchbar">
          <input id="search_in" type="text" placeholder="검색어를 입력하세요" />
        </div>
      </div>

      <div class="prop-wrap" v-show="modalCheck">
        <div class="prop-container">
          <button id="prop_edit">회원정보 수정</button>
          <button id="prop_logout">로그아웃</button>
          <button id="prop_close" @click="modalOpen()">닫기</button>
        </div>
      </div>

      <div id="category_wrap">
        <ul id="category">
          <li>
            <button id="weight">
              <div id="cate_img">
                <img
                  src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='white' d='M12 5c-1.11 0-2 .89-2 2s.89 2 2 2s2-.89 2-2s-.89-2-2-2m10-4v5h-2V4H4v2H2V1h2v2h16V1zm-7 10.26V23h-2v-5h-2v5H9V11.26C6.93 10.17 5.5 8 5.5 5.5V5h2v.5C7.5 8 9.5 10 12 10s4.5-2 4.5-4.5V5h2v.5c0 2.5-1.43 4.67-3.5 5.76'/%3E%3C/svg%3E"
                  width="35px"
                  height="35px"
                />
              </div>
              <div id="cate_name">근력운동</div>
            </button>
          </li>
          <li>
            <RouterLink to="/cardio" id="btn">
              <div id="weight">
                <div id="cate_name"><span>유산소운동</span></div>
              </div>
            </RouterLink>
          </li>

          <li>
            <button id="fitness">
              <div id="cate_img">
                <img
                  src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='white' d='M13.5 5.5c1.09 0 2-.92 2-2a2 2 0 0 0-2-2c-1.11 0-2 .88-2 2c0 1.08.89 2 2 2M9.89 19.38l1-4.38L13 17v6h2v-7.5l-2.11-2l.61-3A7.3 7.3 0 0 0 19 13v-2c-1.91 0-3.5-1-4.31-2.42l-1-1.58c-.4-.62-1-1-1.69-1c-.31 0-.5.08-.81.08L6 8.28V13h2V9.58l1.79-.7L8.19 17l-4.9-1l-.4 2z'/%3E%3C/svg%3E"
                  width="35px"
                  height="35px"
                />
              </div>
              <div id="cate_name">유산소 운동</div>
            </button>
          </li>

          <li>
            <button id="foodtable">
              <div id="cate_img">
                <img
                  src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 20 20'%3E%3Cpath fill='white' d='M6.923 4.833a3.5 3.5 0 0 1 6.242.168a3.75 3.75 0 0 0-3.383 2.321a6.2 6.2 0 0 0-.913-1.173a6.5 6.5 0 0 0-1.946-1.316M16.992 9Q17 8.876 17 8.75a3.75 3.75 0 0 0-2.705-3.603a4.502 4.502 0 0 0-8.314-.67a10 10 0 0 0-1.213-.296A11.5 11.5 0 0 0 2.666 4l-.184.006h-.004a.5.5 0 0 0-.47.47v.001L2 4.665a11.5 11.5 0 0 0 .18 2.105c.123.682.331 1.464.685 2.23H2.5a.5.5 0 0 0-.5.5v.5c0 .69.088 1.36.252 2h15.496A8 8 0 0 0 18 10v-.5a.5.5 0 0 0-.5-.5zM3.984 9c-.434-.782-.682-1.639-.82-2.408a10.5 10.5 0 0 1-.162-1.59l.114.004c.372.013.89.053 1.474.159c1.18.213 2.566.685 3.572 1.691c.616.616 1.033 1.376 1.313 2.144H7.708L5.854 7.146a.5.5 0 1 0-.707.708L6.294 9zm6.548 0l-.027-.081A2.75 2.75 0 1 1 15.99 9zM10 18a8 8 0 0 1-7.418-5h14.837A8 8 0 0 1 10 18'/%3E%3C/svg%3E"
                  width="35px"
                  height="35px"
                />
              </div>
              <div id="cate_name">건강밥상</div>
            </button>
          </li>

          <li>
            <div id="divline"></div>
          </li>

          <li>
            <button id="event">
              <div id="cate_img">
                <img
                  src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='white' d='M9.153 5.408C10.42 3.136 11.053 2 12 2c.947 0 1.58 1.136 2.847 3.408l.328.588c.36.646.54.969.82 1.182c.28.213.63.292 1.33.45l.636.144c2.46.557 3.689.835 3.982 1.776c.292.94-.546 1.921-2.223 3.882l-.434.507c-.476.557-.715.836-.822 1.18c-.107.345-.071.717.001 1.46l.066.677c.253 2.617.38 3.925-.386 4.506c-.766.582-1.918.051-4.22-1.009l-.597-.274c-.654-.302-.981-.452-1.328-.452c-.347 0-.674.15-1.328.452l-.596.274c-2.303 1.06-3.455 1.59-4.22 1.01c-.767-.582-.64-1.89-.387-4.507l.066-.676c.072-.744.108-1.116 0-1.46c-.106-.345-.345-.624-.821-1.18l-.434-.508c-1.677-1.96-2.515-2.941-2.223-3.882c.293-.941 1.523-1.22 3.983-1.776l.636-.144c.699-.158 1.048-.237 1.329-.45c.28-.213.46-.536.82-1.182z'/%3E%3C/svg%3E"
                  width="35px"
                  height="35px"
                />
              </div>
              <div id="cate_name">이벤트</div>
            </button>
          </li>

          <li>
            <RouterLink to="/complain" id="btn">
              <div id="complain">
                <img
                  src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='none' stroke='white' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M16.996 9.013h.008m0-2.004V4.505M22 6.792c0 2.646-2.24 4.792-5.004 4.792q-.488 0-.968-.09c-.23-.043-.344-.064-.425-.052c-.08.012-.194.072-.42.194a3.25 3.25 0 0 1-2.114.329c.274-.338.46-.743.543-1.177c.05-.265-.074-.523-.26-.712a4.67 4.67 0 0 1-1.36-3.284c0-2.646 2.24-4.792 5.004-4.792S22 4.146 22 6.792M7.502 22H4.718c-.323 0-.648-.046-.945-.173c-.966-.415-1.457-.964-1.685-1.307a.54.54 0 0 1 .03-.631c1.12-1.488 3.716-2.386 5.384-2.386M7.507 22h2.783c.324 0 .648-.046.945-.173c.967-.415 1.457-.964 1.686-1.307a.54.54 0 0 0-.03-.631c-1.12-1.488-3.716-2.386-5.384-2.386m2.778-5.214a2.776 2.776 0 0 1-2.778 2.772a2.776 2.776 0 0 1-2.78-2.772a2.776 2.776 0 0 1 2.78-2.773a2.776 2.776 0 0 1 2.778 2.773' color='white'/%3E%3C/svg%3E"
                  width="35px"
                  height="35px"
                />
                <p>고객센터</p>
              </div>
            </RouterLink>
          </li>
        </ul>
      </div>
    </nav>
  </div>
</template>

<script setup>
import { RouterLink, RouterView } from 'vue-router'

var modalCheck = false

function modalOpen() {
  modalCheck.valueOf = true
}
</script>

<style scoped>
@media screen and (max-height: 370px) {
  li {
    display: none;
  }
}
#prop_container {
  width: 244px;
  height: 145px;

  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 20px;
  align-items: center;
  padding-bottom: 20px;
}

#prop_edit {
  width: 244px;
  height: 40px;
  background: rgba(252, 252, 252, 0.55);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
  backdrop-filter: blur(10px);
  border-radius: 10px;
  font-size: 1rem;
  font-family: 'Noto Sans KR';
  font-weight: 600;
  color: white;

  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

#prop_logout {
  width: 244px;
  height: 40px;
  background: rgba(252, 252, 252, 0.55);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
  backdrop-filter: blur(10px);
  border-radius: 10px;
  font-size: 1rem;
  font-family: 'Noto Sans KR';
  font-weight: 600;
  color: white;

  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

#prop_close {
  width: 244px;
  height: 25px;
  background: rgba(252, 252, 252, 0.55);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
  backdrop-filter: blur(10px);
  border-radius: 10px;
  font-size: 13px;
  font-family: 'Noto Sans KR';
  font-weight: 900;
  color: white;

  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

#search_in {
  margin: 0 auto;
  padding-left: 15px;
  width: 95%;
  height: 95%;
  font-size: 15px;
  font-style: normal;
  font-weight: 500;
  font-family: 'Noto Sans KR';
  color: white;
  background: transparent;
  outline: none;
  border: 0;
}

input::placeholder {
  color: #fcfcfc;
}

#divline {
  width: 190px;
  height: 1.5px;
  background-color: white;
  margin-top: 30px;
  margin-bottom: 30px;
  border: none;
  border-radius: 50px;
}

li > button {
  margin: 0;
  padding: 0;
  padding-left: 5px;
  width: 180px;
  height: 45px;
  background: transparent;
  border: none;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  gap: 30px;
}

li > button:hover {
  transform: translateX(10px) scale(1.1);
  transition: transform 0.2s linear;
}

li > button:not(:hover) {
  transition: transform 0.2s linear;
}

nav {
  display: flex;
  margin: 0;
  padding: 0;
  width: 16vw;
  min-width: 320px;
  max-width: 480px;
  height: 100vh;
  background: linear-gradient(333.21deg, #42d665 21.8%, #36bdff 78.2%);
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  flex-wrap: nowrap;
  overflow: hidden;
}

#logo {
  color: white;
  font-size: 20px;
  font-style: normal;
  font-weight: 900;
  font-family: 'Noto Sans KR';
  margin-top: 25px;
  margin-bottom: 20px;
}

#logo:hover {
  background-color: transparent;
}

#wrap01 {
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 20px;
  align-items: center;
  padding-bottom: 20px;
}

#profile {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  gap: 15px;
}

#prop_img {
  background-color: transparent;
  border: 0;
  background: rgba(252, 252, 252, 0.55);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
  backdrop-filter: blur(10px);
  border-radius: 10px;
  width: 60px;
  height: 60px;
}

#profile > button:hover {
  transform: translate(0px, 0px) scale(1.1);
  transition: transform 0.2s linear;
}

#profile > button:not(:hover) {
  transition: transform 0.2s linear;
}

#prop_name {
  width: 170px;
  height: 40px;
  background: rgba(252, 252, 252, 0.35);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
  backdrop-filter: blur(10px);
  border-radius: 10px;
  display: flex;
  flex-direction: row;
  align-items: center;
}

#prop_name > p {
  padding-left: 20px;
  font-style: normal;
  color: white;
  font-size: 1rem;
  font-family: 'Noto Sans KR';
  font-weight: 900;
}

#searchbar {
  width: 244px;
  height: 50px;
  background: rgba(252, 252, 252, 0.35);
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  backdrop-filter: blur(10px);
  border-radius: 10px;
}

#category_wrap {
  display: inline-block;
  width: 244px;
  min-height: 50px;
  max-height: 960px;
  background: rgba(255, 255, 255, 0.35);
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  backdrop-filter: blur(10px);
  border-radius: 10px;
  padding: 10px;
  margin-bottom: 20px;
}

#category {
  margin: 0 auto;
  margin-top: 15px;
  margin-bottom: 15px;
  padding: 0 0;
  margin-right: 10px;
  width: 210px;
  height: 95%;
  overflow-y: hidden;
  list-style: none;
}

#category:hover {
  overflow-y: overlay;
  transition: transform 2s linear;
}

#category::-webkit-scrollbar {
  width: 6px;
}

#category::-webkit-scrollbar-thumb {
  background: #fcfcfc;
  border-radius: 15px 15px 15px 15px;
}
#category::-webkit-scrollbar-track {
  background: rgba(255, 255, 255, 0.6);
  border-radius: 15px 15px 15px 15px;
}

#category::-webkit-scrollbar-button {
  display: none;
}

#btn {
  background-color: red;
  width: 180px;
  height: 70px;
  position: relative;
}

#cate_name {
  margin-left: 10px;
  display: inline-block;
  height: 35px;
  font-size: 20px;
  font-family: 'Noto Sans KR';
  font-weight: 500;
  color: white;
  background-color: #36bdff;
  justify-content: baseline;
  align-items: baseline;
}
</style>
