<template>
  <div>
    <div id="foo">footer</div>
  </div>
</template>

<script setup></script>

<style scoped>
#foo {
  width: 100vw;
  height: 100px;
  background-color: #fcfcfc;
}
</style>
