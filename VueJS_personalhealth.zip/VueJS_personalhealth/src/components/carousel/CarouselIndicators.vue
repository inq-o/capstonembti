<template>
  <div class="wrapper">
    <button
      class="carousel-shortcut"
      :class="{ act: currentIndex === index }"
      v-for="(item, index) in total"
      :key="index"
      @click="openPopup(links[index])"
    >
      <img
        src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='white' d='M12 20c-4.41 0-8-3.59-8-8s3.59-8 8-8s8 3.59 8 8s-3.59 8-8 8m0-18A10 10 0 0 0 2 12a10 10 0 0 0 10 10a10 10 0 0 0 10-10A10 10 0 0 0 12 2m-2 14.5l6-4.5l-6-4.5z'/%3E%3C/svg%3E"
        width="130px"
        height="130px"
      />
    </button>
    <div
      class="carousel-video-info"
      :class="{ actinfo: currentIndex === index }"
      v-for="(item, index) in total"
      :key="index"
    >
      <div class="video-name">{{ names[index] }}</div>
      <div class="video-pub">{{ publishers[index] }}</div>
    </div>
    <div class="carousel-indicators">
      <button
        class="carousel-indicator-item"
        :class="{ active: currentIndex === index }"
        v-for="(item, index) in total"
        :key="index"
        @click="$emit('switch', index)"
      >
        <img :src="slides[index]" />
        <!--{{ names[index] }}-->
      </button>
      <!---
    <button
      class="carousel-shortcut"
      :class="{ active: currentIndex === index }"
      v-for="(item, index) in total"
      :key="index"
      @click="alert('hello')"
    >
      <a href="https://www.naver.com"> 버튼{{ index + 1 }} </a>
    </button> -->
    </div>

    <div v-show="modalkey" class="food_modal">
      <div class="notice">추천하는 식단을 확인하러 가시겠습니까?</div>
      <div class="btn_wrap">
        <button @click="checkCategory()">예</button>
        <button @click="modalkey = false">아니오</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  emits: ['switch'],
  props: ['total', 'currentIndex', 'slides', 'names', 'links', 'publishers', 'category'],
  data() {
    return {
      modalkey: false
    }
  },
  methods: {
    openPopup(url) {
      const popup = window.open(url, '_blank', 'width=800, height=600')
      const checkPopupClosed = setInterval(() => {
        if (popup.closed) {
          clearInterval(checkPopupClosed)
          this.onPopupClosed()
        }
        return false
      }, 1000)
    },
    onPopupClosed() {
      this.Openfoodtable()
    },
    Openfoodtable() {
      this.modalkey = true
    },
    checkCategory() {
      if (this.category[this.currentIndex] === '근력운동') {
        this.$router.push('/foodtable')
      } else if (this.category[this.currentIndex] === '다이어트') {
        this.$router.push('/foodtablecardio')
      }
    }
  }
}
</script>

<style scoped>
@media screen and (max-width: 1240px) {
  .carousel-indicators {
    flex-wrap: wrap;
    gap: 20px;
  }
  .carousel-indicator-item {
    flex-basis: 0;
    flex-grow: 0;
    min-width: 120px;
  }

  .act {
    position: absolute;
    left: 50%;
    top: 10px;
    transform: translate(-50%);
  }

  .carousel-shortcut:hover {
    margin: 0;
    padding: 0;
    border-radius: 50%;
  }

  .carousel-video-info {
    display: none;
  }

  .actinfo {
    display: none;
  }
}

@media screen and (min-width: 1241px) {
  .carousel-indicators {
    flex-wrap: nowrap;
    gap: 1vw;
  }

  .carousel-indicator-item {
    flex-basis: 6.4vw;
    flex-grow: 1;
    min-width: 60px;
  }

  .act {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
  }

  .carousel-shortcut:hover {
    padding: 7px;
    border-radius: 15%;
  }

  .carousel-video-info {
    display: none;
  }

  .actinfo {
    display: flex;
  }
}
.carousel-indicators {
  width: 90%;
  position: absolute;
  transform: translate(-50%);
  left: 50%;
  bottom: 50px;
  z-index: 2;
  display: flex;
}
.carousel-indicator-item {
  max-height: 180px;
  height: 16vh;
  min-height: 60px;
  border: none;
  background: rgba(252, 252, 252, 0.3);
  backdrop-filter: blur(20px);
  margin: 0 auto;
  border-radius: 10px;
  cursor: pointer;
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
  padding: 10px;
}
.carousel-indicator-item > img {
  width: 96%;
  height: 96%;
  border-radius: 10px;
}

.carousel-indicator-item:hover {
  transform: scale(0.95);
  transition-duration: 0.2s;
}

.active {
  opacity: 1;
  transform: scale(1.1);
  transition-duration: 0.2s;
  background: linear-gradient(333.21deg, #42d665 21.8%, #36bdff 78.2%);
  color: white;
  z-index: 1;
}

.carousel-shortcut {
  display: none;
}

.act {
  display: block;
  z-index: 3;
  border: 0;
  background-color: transparent;
  opacity: 0.6;
}

a:hover {
  background-color: transparent;
}

.carousel-shortcut:hover {
  background: linear-gradient(333.21deg, #42d665 21.8%, #36bdff 78.2%);
  opacity: 1;
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
  cursor: pointer;
}

.actinfo {
  z-index: 100;
  position: absolute;
  left: 50%;
  top: 30px;
  background: rgba(252, 252, 252, 0.3);
  backdrop-filter: blur(20px);
  padding-top: 10px;
  padding-bottom: 10px;

  min-width: 500px;
  max-width: 500px;
  height: 120px;
  border-radius: 15px;
  transform: translate(-50%);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);

  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.video-name {
  padding-left: 20px;
  padding-right: 20px;
  display: block;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  text-align: center;
  min-width: 50px;
  max-width: 500px;
  font-size: clamp(25px, 1.7vw, 35px);
  font-weight: 800;
  color: white;
  font-family: 'Noto Sans KR';
  height: fit-content;
}

.actinfo:hover {
  cursor: pointer;
  min-width: fit-content;
  width: fit-content;
  max-width: fit-content;
  min-height: 120px;
  height: fit-content;
}

.actinfo > .video-name:hover {
  display: flex;
  overflow: visible;
  min-width: fit-content;
  width: fit-content;
  max-width: fit-content;
  padding: 0 10px;
  transition-duration: 0.2s;
}

.video-pub {
  display: block;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  text-align: center;
  width: 400px;
  height: fit-content;
  font-size: 25px;
  font-weight: 600;
  font-family: 'Noto Sans KR';
  color: white;
}

.food_modal {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 5;
  background: rgba(252, 252, 252, 0.3);
  min-width: 60%;
  min-height: 30px;
  width: fit-content;
  height: fit-content;
  padding: 20px;
  backdrop-filter: blur(20px);
  border-radius: 18px;

  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
  gap: clamp(50px, 7vh, 100px);
}
.notice {
  font-size: clamp(20px, 2vw, 30px);
  font-weight: 800;
  color: white;
  font-family: 'Noto Sans KR';
  background: rgba(0, 0, 0, 0.1);
  padding: 15px;
  border-radius: 10px;
  margin-top: 20px;
}

.btn_wrap {
  width: 60%;
  height: 70px;
  display: flex;
  justify-content: center;
  gap: 50px;
}

.btn_wrap > button {
  width: 50%;
  background: rgba(252, 252, 252, 0.4);
  border: 0;
  padding: clamp(10px, 1vw, 20px);
  font-size: clamp(12px, 1.2vw, 20px);
  border-radius: 10px;
  color: #575757;
  font-family: 'Noto Sans KR';
  font-weight: 700;
  cursor: pointer;
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
}

.btn_wrap > button:hover {
  background: linear-gradient(333.21deg, #42d665 21.8%, #36bdff 78.2%);
  color: white;
  transform: scale(0.95);
  transition-duration: 0.2s;
}
</style>
