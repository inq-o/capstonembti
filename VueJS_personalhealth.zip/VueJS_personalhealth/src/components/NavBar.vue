<script>
import { RouterLink, RouterView } from 'vue-router'
export default {
  props: {
    username: {
      type: Text,
      required: true,
      default: 'placeholder'
    }
  }
}
</script>

<template>
  <div id="wrap">
    <nav>
      <RouterLink to="/weight" id="logo">PersonalHealth</RouterLink>

      <div id="wrap01">
        <div id="profile">
          <button id="prop_img">
            <img
              src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='white' d='M12 4a4 4 0 0 1 4 4a4 4 0 0 1-4 4a4 4 0 0 1-4-4a4 4 0 0 1 4-4m0 10c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4'/%3E%3C/svg%3E"
              width="35px"
              height="35px"
            />
          </button>
          <div id="prop_name">
            <p>{{ username }}</p>
          </div>
        </div>

        <button id="prop_btn">회원정보 수정</button>
        <RouterLink to="/" id="prop_btn">로그아웃</RouterLink>
      </div>

      <div id="category_wrap">
        <ul id="category">
          <li>
            <RouterLink to="/weight" id="btn">
              <img
                src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='white' d='M12 5c-1.11 0-2 .89-2 2s.89 2 2 2s2-.89 2-2s-.89-2-2-2m10-4v5h-2V4H4v2H2V1h2v2h16V1zm-7 10.26V23h-2v-5h-2v5H9V11.26C6.93 10.17 5.5 8 5.5 5.5V5h2v.5C7.5 8 9.5 10 12 10s4.5-2 4.5-4.5V5h2v.5c0 2.5-1.43 4.67-3.5 5.76'/%3E%3C/svg%3E"
                width="35px"
                height="35px"
              />
              <p id="cate_name">근력운동</p></RouterLink
            >
          </li>

          <li>
            <RouterLink to="/cardio" id="btn"
              ><img
                src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='white' d='M13.5 5.5c1.09 0 2-.92 2-2a2 2 0 0 0-2-2c-1.11 0-2 .88-2 2c0 1.08.89 2 2 2M9.89 19.38l1-4.38L13 17v6h2v-7.5l-2.11-2l.61-3A7.3 7.3 0 0 0 19 13v-2c-1.91 0-3.5-1-4.31-2.42l-1-1.58c-.4-.62-1-1-1.69-1c-.31 0-.5.08-.81.08L6 8.28V13h2V9.58l1.79-.7L8.19 17l-4.9-1l-.4 2z'/%3E%3C/svg%3E"
                width="35px"
                height="35px"
              />
              <p id="cate_name">유산소운동</p></RouterLink
            >
          </li>

          <li>
            <RouterLink to="/foodtable" id="btn"
              ><img
                src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 20 20'%3E%3Cpath fill='white' d='M6.923 4.833a3.5 3.5 0 0 1 6.242.168a3.75 3.75 0 0 0-3.383 2.321a6.2 6.2 0 0 0-.913-1.173a6.5 6.5 0 0 0-1.946-1.316M16.992 9Q17 8.876 17 8.75a3.75 3.75 0 0 0-2.705-3.603a4.502 4.502 0 0 0-8.314-.67a10 10 0 0 0-1.213-.296A11.5 11.5 0 0 0 2.666 4l-.184.006h-.004a.5.5 0 0 0-.47.47v.001L2 4.665a11.5 11.5 0 0 0 .18 2.105c.123.682.331 1.464.685 2.23H2.5a.5.5 0 0 0-.5.5v.5c0 .69.088 1.36.252 2h15.496A8 8 0 0 0 18 10v-.5a.5.5 0 0 0-.5-.5zM3.984 9c-.434-.782-.682-1.639-.82-2.408a10.5 10.5 0 0 1-.162-1.59l.114.004c.372.013.89.053 1.474.159c1.18.213 2.566.685 3.572 1.691c.616.616 1.033 1.376 1.313 2.144H7.708L5.854 7.146a.5.5 0 1 0-.707.708L6.294 9zm6.548 0l-.027-.081A2.75 2.75 0 1 1 15.99 9zM10 18a8 8 0 0 1-7.418-5h14.837A8 8 0 0 1 10 18'/%3E%3C/svg%3E"
                width="35px"
                height="35px"
              />
              <p id="cate_name">건강밥상</p></RouterLink
            >
          </li>

          <li>
            <div id="divline"></div>
          </li>

          <li>
            <RouterLink to="/complain" id="btn">
              <img
                src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='none' stroke='white' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M16.996 9.013h.008m0-2.004V4.505M22 6.792c0 2.646-2.24 4.792-5.004 4.792q-.488 0-.968-.09c-.23-.043-.344-.064-.425-.052c-.08.012-.194.072-.42.194a3.25 3.25 0 0 1-2.114.329c.274-.338.46-.743.543-1.177c.05-.265-.074-.523-.26-.712a4.67 4.67 0 0 1-1.36-3.284c0-2.646 2.24-4.792 5.004-4.792S22 4.146 22 6.792M7.502 22H4.718c-.323 0-.648-.046-.945-.173c-.966-.415-1.457-.964-1.685-1.307a.54.54 0 0 1 .03-.631c1.12-1.488 3.716-2.386 5.384-2.386M7.507 22h2.783c.324 0 .648-.046.945-.173c.967-.415 1.457-.964 1.686-1.307a.54.54 0 0 0-.03-.631c-1.12-1.488-3.716-2.386-5.384-2.386m2.778-5.214a2.776 2.776 0 0 1-2.778 2.772a2.776 2.776 0 0 1-2.78-2.772a2.776 2.776 0 0 1 2.78-2.773a2.776 2.776 0 0 1 2.778 2.773' color='white'/%3E%3C/svg%3E"
                width="35px"
                height="35px"
              />
              <p id="cate_name">고객센터</p></RouterLink
            >
          </li>
        </ul>
      </div>
    </nav>
  </div>
</template>

<style scoped>
@media screen and (max-height: 370px) {
  li {
    display: none;
  }
}

.fade-enter {
  opacity: 0;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s ease-out;
}

.fade-leave-to {
  opacity: 0;
}

#prop_btn {
  width: 244px;
  height: 40px;
  background: rgba(252, 252, 252, 0.35);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
  backdrop-filter: blur(10px);
  border-radius: 10px;
  font-size: 1rem;
  font-family: 'Noto Sans KR';
  font-weight: 600;
  color: white;
  border: 0;

  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

#prop_btn:hover {
  background: rgba(255, 255, 255, 0.55);
  transform: scale(0.95);
  transition-duration: 0.1s;
}

#divline {
  width: 190px;
  height: 1.5px;
  background-color: white;
  margin-top: 20px;
  margin-bottom: 20px;
  border: none;
  border-radius: 50px;
}

li > button {
  margin: 0;
  padding: 0;
  padding-left: 5px;
  width: 180px;
  height: 45px;
  background: transparent;
  border: none;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  gap: 30px;
}

nav {
  display: flex;
  margin: 0;
  padding: 0;
  width: 16vw;
  min-width: 320px;
  max-width: 480px;
  height: 100vh;
  background: linear-gradient(333.21deg, #42d665 21.8%, #36bdff 78.2%);
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  flex-wrap: nowrap;
  overflow: hidden;
}

#logo {
  color: white;
  font-size: 20px;
  font-style: normal;
  font-weight: 900;
  font-family: 'Noto Sans KR';
  margin-top: 25px;
  margin-bottom: 20px;
}

#logo:hover {
  background-color: transparent;
}

#wrap01 {
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 20px;
  align-items: center;
  padding-bottom: 20px;
}

#profile {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  gap: 15px;
}

#prop_img {
  background-color: transparent;
  border: 0;
  background: rgba(252, 252, 252, 0.55);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
  backdrop-filter: blur(10px);
  border-radius: 10px;
  width: 60px;
  height: 60px;
}

#prop_name {
  width: 170px;
  height: 40px;
  background: rgba(252, 252, 252, 0.35);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
  backdrop-filter: blur(10px);
  border-radius: 10px;
  display: flex;
  flex-direction: row;
  align-items: center;
}

#prop_name > p {
  padding-left: 20px;
  font-style: normal;
  color: white;
  font-size: 1rem;
  font-family: 'Noto Sans KR';
  font-weight: 900;
}

#category_wrap {
  display: inline-block;
  width: 244px;
  min-height: 50px;
  height: 40vh;
  max-height: 400px;
  background: rgba(255, 255, 255, 0.35);
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  backdrop-filter: blur(10px);
  border-radius: 10px;
  padding: 10px;
  margin-bottom: 20px;
}

#category {
  border-radius: 10px;
  margin: 0 auto;
  margin-top: 15px;
  margin-bottom: 15px;
  padding: 0 0;
  margin-right: 10px;
  width: 210px;
  height: 80%;
  overflow-y: hidden;
  list-style: none;
}

#category:hover {
  overflow-y: overlay;
  transition: transform 2s linear;
}

#category::-webkit-scrollbar {
  width: 6px;
}

#category::-webkit-scrollbar-thumb {
  background: #fcfcfc;
  border-radius: 15px 15px 15px 15px;
}
#category::-webkit-scrollbar-track {
  background: rgba(255, 255, 255, 0.6);
  border-radius: 15px 15px 15px 15px;
}

#category::-webkit-scrollbar-button {
  display: none;
}

#btn {
  width: 190px;
  height: 45px;
  display: flex;
  gap: 25px;
  padding-left: 10px;
  padding-right: 10px;
  margin-bottom: 10px;
  align-items: center;
}

#cate_name {
  display: inline-flex;
  padding: 0;
  margin-left: 0px;
  font-size: 20px;
  font-family: 'Noto Sans KR';
  font-weight: 800;
  color: white;
  align-items: center;
}

a {
  background-color: transparent;
  text-decoration: none;
}

a:hover {
  background: rgba(255, 255, 255, 0.55);
  border-radius: 10px;
}
</style>
