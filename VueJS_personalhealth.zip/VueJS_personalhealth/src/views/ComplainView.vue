<template>
  <div id="wrapper">
    <div id="header">
      <NavBar :username="username"></NavBar>
    </div>
    <div id="section">
      <div id="imgslider">COMPLAIN</div>
    </div>
  </div>
</template>

<script setup>
import NavBar from '../components/NavBar.vue'
</script>
<script>
export default {
  name: 'app',
  data() {
    return {
      username: '경기대학교'
    }
  },
  created() {
    document.title = '고객센터 - PersonalHealth'
  }
}
</script>

<style scoped>
@media screen and (max-width: 640px) {
  #section {
    display: none;
  }
}
#wrapper {
  position: absolute;
  left: 0;
  top: 0;
  margin: 0 0;
  padding: 0 0;

  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  flex-wrap: nowrap;
  width: 100vw;
}

#navbar {
  margin: 0 0;
  padding: 0 0;
  flex-basis: 16vw;
  min-width: 320px;
  max-width: 480px;
}

#section {
  flex-basis: 84vw;
  flex-grow: 1;
  height: 100vh;
}
</style>
