<template>
  <main>
    <div class="logo"><span>로그인 하세요!</span></div>
    <div class="loginbox">
      <div class="inp">
        <div class="id">
          <label for="id">아이디</label>
          <input
            type="text"
            name="id"
            v-model="userid"
            @input="checkvalidid(), checkvalid()"
            placeholder="아이디를 입력하세요"
          />
        </div>

        <div class="pwd">
          <label for="pwd">비밀번호</label>
          <input
            type="password"
            name="pwd"
            v-model="userpw"
            placeholder="비밀번호를 입력하세요"
            @input="checkvalidpw(), checkvalid()"
          />
        </div>
      </div>

      <div class="btn_wrap">
        <button type="submit" id="signin" @click="checklogin()">로그인</button>
        <button type="button" id="signup" @click="this.$router.push('/signup')">회원가입</button>
      </div>
      <button type="button" id="findpwd" onclick="location.href='#'">비밀번호 찾기</button>
    </div>
  </main>
</template>

<script>
import axios from 'axios'

export default {
  components: {},
  data() {
    return {
      userid: '',
      userpw: '',
      username: '',
      idkey: false,
      pwkey: false,
      idpwkey: false,
      userarr: []
    }
  },
  methods: {
    checkvalidid() {
      this.idkey = this.userarr.some((user) => user.id === this.userid) == true
    },
    checkvalidpw() {
      this.pwkey = this.userarr.some((user) => user.pw === this.userpw) == true
    },
    checkvalid() {
      const user = this.userarr.find((user) => user.id === this.userid && user.pw === this.userpw)
      this.username = user.name
      this.idpwkey = !!user
    },
    checklogin() {
      if (this.idkey == true && this.pwkey == true && this.idpwkey == true) {
        alert(this.username + '님, 환영합니다!')
        this.$router.push('/weight')
      } else if (this.idpwkey == false) {
        alert('회원정보가 없습니다.')
      }
    },
    userget() {
      axios
        .get('https://kgubsh.loca.lt/api/users/')
        .then((response) => {
          this.userarr = response.data // 데이터를 this.idarr에 저장
        })
        .catch((err) => {
          console.log(err)
        })
    }
  },
  created() {
    document.title = '로그인하세요!'
  },
  mounted() {
    this.userget()
  }
}
</script>

<style scoped>
.btn_wrap {
  width: 85%;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  gap: 20px;
}
main {
  overflow: hidden;
  position: absolute;
  left: 0;
  top: 0;
  width: 100vw;
  height: 100vh;
  background: linear-gradient(295.45deg, #36b2ff 11.41%, #42d665 88.59%);
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
}

.logo {
  margin-top: 100px;
  background: linear-gradient(295.45deg, #36b2ff 11.41%, #42d665 88.59%);
  width: 240px;
  height: 80px;
  border-radius: 15px;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  display: inline-flex;
  justify-content: center;
  align-items: center;
}

.logo > span {
  color: white;
  font-family: 'Noto Sans KR';
  font-size: 28px;
  font-style: normal;
  font-weight: 900;
  transform: rotate(0.04deg);
}
.loginbox {
  margin-top: 50px;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 15px;
  min-width: 400px;
  max-width: 660px;
  width: 50vw;
  min-height: 330px;
  height: fit-content;
  background-color: #fcfcfc;
  padding-top: 50px;
  padding-bottom: 50px;

  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 35px;
}

input {
  width: 70%;
  border-top: none;
  border-right: none;
  border-left: none;
  border-bottom: 2px solid #575757;

  font-size: 18px;
  font-family: 'Noto Sans KR';
  font-style: normal;
  font-weight: 500;
  color: #575757;
  transform: rotate(0.04deg);
  padding-bottom: 8px;
  text-indent: 5px;
}

input::placeholder {
  color: rgba(0, 0, 0, 0.45);
}

input:focus {
  outline: none;
}

label {
  font-size: 20px;
  font-family: 'Noto Sans KR';
  font-style: normal;
  font-weight: 900;
  color: #575757;
  margin-right: 15px;
  transform: rotate(0.04deg);
}

.id {
  width: 100%;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}

.pwd {
  width: 100%;
  margin-top: 20px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}

#findpwd {
  display: inline-block;
  width: 105px;
  height: 27px;
  border: none;
  background-color: #fcfcfc;
  color: rgba(87, 87, 87, 0.45);
  font-size: 14px;
  font-family: 'Noto Sans KR';
  font-weight: 500;
  font-style: normal;
  padding: 0;
  cursor: pointer;
}

#signup {
  width: 260px;
  height: 55px;
  background: linear-gradient(280.79deg, #36b2ff 30.42%, #42d665 69.58%);
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border: none;
  border-radius: 10px;
  font-family: 'Noto Sans KR';
  font-style: normal;
  font-weight: 900;
  font-size: 20px;
  color: #ffffff;
  transform: rotate(0.04deg);
  cursor: pointer;
}

#signin {
  width: 260px;
  height: 55px;

  background: linear-gradient(280.79deg, #36b2ff 30.42%, #42d665 69.58%);
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border: none;
  border-radius: 10px;
  font-family: 'Noto Sans KR';
  font-style: normal;
  font-weight: 900;
  font-size: 20px;
  color: #ffffff;
  transform: rotate(0.04deg);
  cursor: pointer;
}

#signup:hover {
  transform: scale(0.97);
  transition: transform 0.1s linear;
  background: #575757;
}

#signup:not(:hover) {
  transition: transform 0.1s linear;
}

#signin:hover {
  transform: scale(0.97);
  transition: transform 0.1s linear;
  background: #575757;
}

#signin:not(:hover) {
  transition: transform 0.1s linear;
}

#inp {
  width: 100%;
}
</style>
