<template>
  <main>
    <div class="logo"><span>회원가입을 진행하세요!</span></div>

    <div id="info">
      <div class="id_wrap">
        <div id="label">
          <p>아이디</p>
          <input v-model="userid" @input="checkid" placeholder="소문자 및 숫자로 입력해주세요" />
          <img
            v-show="uidkey"
            src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='%2370cd98' fill-rule='evenodd' d='M12 21a9 9 0 1 0 0-18a9 9 0 0 0 0 18m-.232-5.36l5-6l-1.536-1.28l-4.3 5.159l-2.225-2.226l-1.414 1.414l3 3l.774.774z' clip-rule='evenodd'/%3E%3C/svg%3E"
          />
        </div>
        <div class="idalert">{{ idalert }}</div>
      </div>

      <div id="label">
        <p>비밀번호</p>
        <input v-model="userpw" @input="checkpw()" placeholder="6자리 숫자로 입력해주세요" />
        <img
          v-show="upwkey"
          src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='%2370cd98' fill-rule='evenodd' d='M12 21a9 9 0 1 0 0-18a9 9 0 0 0 0 18m-.232-5.36l5-6l-1.536-1.28l-4.3 5.159l-2.225-2.226l-1.414 1.414l3 3l.774.774z' clip-rule='evenodd'/%3E%3C/svg%3E"
        />
      </div>

      <div id="label">
        <p>MBTI</p>
        <input v-model="usermbti" @input="checkmbti()" placeholder="대문자로 입력해주세요" />
        <img
          v-show="mbtikey"
          src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='%2370cd98' fill-rule='evenodd' d='M12 21a9 9 0 1 0 0-18a9 9 0 0 0 0 18m-.232-5.36l5-6l-1.536-1.28l-4.3 5.159l-2.225-2.226l-1.414 1.414l3 3l.774.774z' clip-rule='evenodd'/%3E%3C/svg%3E"
        />
      </div>

      <div id="label">
        <p>이름</p>
        <input v-model="username" @input="checkname()" />
        <img
          v-show="namekey"
          src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='%2370cd98' fill-rule='evenodd' d='M12 21a9 9 0 1 0 0-18a9 9 0 0 0 0 18m-.232-5.36l5-6l-1.536-1.28l-4.3 5.159l-2.225-2.226l-1.414 1.414l3 3l.774.774z' clip-rule='evenodd'/%3E%3C/svg%3E"
        />
      </div>

      <div id="label">
        <p>생년월일</p>
        <input type="date" v-model="userbirth" />
        <img
          v-show="userbirth !== ''"
          src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='%2370cd98' fill-rule='evenodd' d='M12 21a9 9 0 1 0 0-18a9 9 0 0 0 0 18m-.232-5.36l5-6l-1.536-1.28l-4.3 5.159l-2.225-2.226l-1.414 1.414l3 3l.774.774z' clip-rule='evenodd'/%3E%3C/svg%3E"
        />
      </div>

      <div id="label">
        <p>성별</p>
        <div id="wrap_btn">
          <button
            class="gender_m"
            @click="usergender = '남성'"
            :class="{ selected: usergender === '남성' }"
          >
            <span>남성</span>
          </button>
          <button
            class="gender_f"
            @click="usergender = '여성'"
            :class="{ selected: usergender === '여성' }"
          >
            <span>여성</span>
          </button>
        </div>
      </div>

      <div id="label">
        <p>전화번호</p>
        <input v-model="usercontact" @input="checkcontact()" />
        <img
          v-show="contactkey"
          src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='%2370cd98' fill-rule='evenodd' d='M12 21a9 9 0 1 0 0-18a9 9 0 0 0 0 18m-.232-5.36l5-6l-1.536-1.28l-4.3 5.159l-2.225-2.226l-1.414 1.414l3 3l.774.774z' clip-rule='evenodd'/%3E%3C/svg%3E"
        />
      </div>

      <div id="label">
        <p>키</p>
        <input v-model="userheight" @input="checkheight()" />
        <img
          v-show="heightkey"
          src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='%2370cd98' fill-rule='evenodd' d='M12 21a9 9 0 1 0 0-18a9 9 0 0 0 0 18m-.232-5.36l5-6l-1.536-1.28l-4.3 5.159l-2.225-2.226l-1.414 1.414l3 3l.774.774z' clip-rule='evenodd'/%3E%3C/svg%3E"
        />
      </div>

      <div id="label">
        <p>체중</p>
        <input v-model="userweight" @input="checkweight()" />
        <img
          v-show="weightkey"
          src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='%2370cd98' fill-rule='evenodd' d='M12 21a9 9 0 1 0 0-18a9 9 0 0 0 0 18m-.232-5.36l5-6l-1.536-1.28l-4.3 5.159l-2.225-2.226l-1.414 1.414l3 3l.774.774z' clip-rule='evenodd'/%3E%3C/svg%3E"
        />
      </div>

      <div id="check">
        <span>가입에 동의합니다</span>
        <input type="checkbox" v-model="useraccept" value="동의합니다" id="accept" />
      </div>
      <button v-bind:disabled="checkvalue() == false" @click="submitsignup" id="smt">
        <span>가입하기!</span>
      </button>
    </div>
  </main>
</template>

<script>
import db from '../../assets/test_db2.json'
import axios from 'axios'

export default {
  data() {
    return {
      userid: '',
      userpw: '',
      usermbti: '',
      username: '',
      userbirth: '',
      usergender: '',
      usercontact: '010 - ' + '',
      userheight: '' + 'cm',
      userweight: '' + 'kg',
      useraccept: '',
      smtcheck: '',
      uidkey: false,
      upwkey: false,
      mbtikey: false,
      namekey: false,
      contactkey: false,
      heightkey: false,
      weightkey: false,
      idalert: '',
      idarr: []
    }
  },
  methods: {
    checkid() {
      const id = /^[a-z-0-9]{4,15}$/
      this.idget()
      if (id.test(this.userid)) {
        if (this.idarr.some((user) => user.id === this.userid) == true) {
          this.uidkey = false
          this.idalert = '이미 존재하는 아이디입니다. 다른 아이디를 입력 바랍니다'
        } else {
          this.uidkey = true
          this.idalert = ''
        }
      } else {
        this.uidkey = false
        this.idalert = ''
      }
    },
    checkpw() {
      const pw = /^[0-9]{6}$/
      if (pw.test(this.userpw)) {
        this.upwkey = true
      } else {
        this.upwkey = false
      }
    },
    checkmbti() {
      const mbti = [
        'ISTJ',
        'ISTP',
        'ISFJ',
        'ISFP',
        'INTJ',
        'INTP',
        'INFJ',
        'INFP',
        'ESTJ',
        'ESTP',
        'ESFJ',
        'ESFP',
        'ENTJ',
        'ENTP',
        'ENFJ',
        'ENFP'
      ]
      this.mbtikey = mbti.includes(this.usermbti)
    },
    checkname() {
      const name = /^[가-힣]{2,15}$/
      if (name.test(this.username)) {
        this.namekey = true
      } else {
        this.namekey = false
      }
    },
    checkcontact() {
      const contact = /^010 - [0-9]{8}$/
      if (contact.test(this.usercontact)) {
        this.contactkey = true
      } else {
        this.contactkey = false
      }
    },
    checkheight() {
      const height = /^[0-9]{3}cm$/
      if (height.test(this.userheight)) {
        this.heightkey = true
      } else {
        this.heightkey = false
      }
    },
    checkweight() {
      const weight = /^[0-9]{2,3}kg$/
      if (weight.test(this.userweight)) {
        this.weightkey = true
      } else {
        this.weightkey = false
      }
    },
    checkvalue() {
      if (
        this.uidkey == true &&
        this.upwkey == true &&
        this.mbtikey == true &&
        this.namekey == true &&
        this.contactkey == true &&
        this.usergender != '' &&
        this.heightkey == true &&
        this.weightkey == true &&
        this.useraccept == true &&
        this.userbirth != ''
      ) {
        return true
      } else {
        return false
      }
    },
    /*submitsignup() {
      db[6] = {
        userid: this.userid,
        userpw: this.userpw,
        usermbti: this.usermbti,
        username: this.username,
        usercontact: this.usercontact,
        userbirth: this.userbirth,
        usergender: this.usergender,
        userheight: this.userheight,
        userweight: this.userweight
      } */

    async submitsignup() {
      const userData = {
        id: this.userid,
        pw: this.userpw,
        usermbti: this.usermbti,
        name: this.username,
        phonenumber: this.usercontact,
        birthdate: this.userbirth,
        sex: this.usergender,
        height: this.userheight,
        weight: this.userweight
      }
      try {
        const response = await axios.post('https://kgubsh.loca.lt/api/users/', userData)
        console.log(response.data)
        alert(this.username + '님, 가입을 진심으로 환영합니다!')
        this.$router.push('/videopick')
      } catch (error) {
        console.error('Error submitting signup:', error)
      }
    },
    idget() {
      axios
        .get('https://kgubsh.loca.lt/api/users/?format=json')
        .then((response) => {
          this.idarr = response.data // 데이터를 this.idarr에 저장
        })
        .catch((err) => {
          console.log(err)
        })
    }
  },
  created() {
    document.title = '회원가입을 진행하세요!'
  }
}
</script>

<style scoped>
input::placeholder {
  color: #9c9c9c;
  font-weight: 400;
}
main {
  overflow: hidden;
  position: absolute;
  left: 0;
  top: 0;
  width: 100%;
  background: linear-gradient(295.45deg, #36b2ff 11.41%, #42d665 88.59%);
  display: flex;
  flex-direction: column;
  align-items: center;
}

.logo {
  margin-top: 50px;
  background: linear-gradient(295.45deg, #36b2ff 11.41%, #42d665 88.59%);
  width: 300px;
  height: 70px;
  border-radius: 15px;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  display: flex;
  justify-content: center;
  align-items: center;
}

.logo > span {
  color: white;
  font-family: 'Noto Sans KR';
  font-size: 25px;
  font-style: normal;
  font-weight: 900;
  transform: rotate(0.04deg);
}

#info {
  position: relative;
  margin-top: 50px;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 25px;
  max-width: 640px;
  width: 50vw;
  min-width: 400px;
  height: fit-content;
  background-color: #fcfcfc;
  margin-bottom: 100px;

  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  padding-top: 50px;
  padding-bottom: 50px;
  gap: 30px;
}

#label {
  width: 80%;
  height: 50px;
  margin-bottom: 10px;
  border-radius: 10px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.25);
  display: flex;
  justify-content: flex-start;
  align-items: center;
  background-color: white;
}

input {
  display: inline-block;
  width: 50%;
  height: 50px;
  margin-left: clamp(5px, 4vw, 60px);
  outline: none;
  border: 0;
  font-size: 16px;
  font-family: 'Noto Sans KR';
  font-weight: 600;
  color: #575757;
}

p {
  background: linear-gradient(295.45deg, #36b2ff 11.41%, #42d665 88.59%);
  width: 90px;
  height: 50px;
  margin: 0;
  padding: 0;

  display: flex;
  justify-content: center;
  align-items: center;
  border-top-left-radius: 10px;
  border-bottom-left-radius: 10px;

  font-weight: 500;
  color: white;
  font-family: 'Noto Sans KR';
  font-size: 1rem;
}

#wrap_btn {
  width: 100px;
  flex-grow: 1;
  height: 50px;
  display: flex;
  justify-content: space-between;
}

#wrap_btn > button {
  width: 50%;
  height: 100%;
  border: none;
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  margin: 0;
}

.gender_m {
  background-color: #7c9dcd;
}

.gender_f {
  background-color: #ef5898;
  border-top-right-radius: 10px;
  border-bottom-right-radius: 10px;
}

.selected {
  background-color: #575757;
}

button > span {
  color: white;
  font-size: 1.2rem;
  font-family: 'Noto Sans KR';
  font-weight: 700;
}

#check {
  width: 80%;
  height: 50px;
  padding-left: 20px;

  display: flex;
  justify-content: flex-start;
  align-items: center;
  gap: 10px;
}

#check > span {
  margin-right: 10px;
  color: #575757;
  font-size: 1rem;
  font-weight: 600;
  font-family: 'Noto Sans KR';
}

#accept {
  margin: 0;
  width: 20px;
  height: 20px;
  border: 0;
}

#smt {
  border: none;
  background: #575757;
  width: 100px;
  height: 50px;
  border-radius: 10px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.25);
}

#smt:disabled {
  background: #575757;
}

#smt > span {
  font-size: 1.2rem;
  font-weight: 500;
}

#smt:enabled {
  background: linear-gradient(295.45deg, #36b2ff 11.41%, #42d665 88.59%);
}

#smt:enabled:hover {
  transform: scale(1.1);
  transition-duration: 0.2s linear;
}

img {
  margin-left: 20px;
  width: 30px;
  height: 30px;
}

.id_wrap {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 10px;
  width: 100%;
}

.idalert {
  width: 90%;
  text-align: center;
  font-size: 0.9rem;
  font-weight: 600;
  font-family: 'Noto Sans KR';
  color: red;
}
</style>
