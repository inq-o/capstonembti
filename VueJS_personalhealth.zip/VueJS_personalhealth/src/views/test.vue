<template>
  <div id="header">
    <NavBar id="navbar" :username="username"></NavBar>
  </div>
  <carousel
    :slides="slides"
    :names="names"
    :links="links"
    :publishers="publishers"
    :interval="30000"
    controls
    indicators
  ></carousel>
</template>

<script>
import NavBar from '../components/NavBar.vue'
import Carousel from '../components/carousel/Carousel.vue'
import category from '../assets/test_db.json'
import img from '../assets/test_db2.json'

export default {
  name: 'App',
  components: { Carousel, NavBar },
  data: () => ({
    slides: img[1].slides,
    names: img[0].names,
    links: img[0].links,
    username: img[2].username,
    publishers: img[0].publishers
  })
}
</script>

<style>
#navbar {
  z-index: 3;
}

#navbar {
  position: absolute;
  left: 0;
  top: 0;
  flex-basis: 16vw;
  min-width: 320px;
  max-width: 480px;
}
</style>
