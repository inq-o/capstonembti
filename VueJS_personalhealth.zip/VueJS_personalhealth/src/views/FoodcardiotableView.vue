<script setup>
import NavBar from '../components/NavBar.vue'
</script>

<template>
  <div id="wrapper">
    <div id="header">
      <NavBar :username="username"></NavBar>
    </div>
    <div class="section">
      <div class="food_logo">유산소운동에 추천하는 식단입니다!</div>
      <button class="category_change" @click="$router.push('/foodtable')">
        <div class="imgbox"></div>
        <div class="text">근력운동</div>
      </button>

      <div class="food_line">
        <div v-show="this.time === this.breakfast" class="food_slide_breakfast">
          <div class="silde_left">
            <div class="food_image">
              <img :src="food_img_breakfast" />
            </div>
            <div class="food_name">
              <p>{{ food_name_breakfast }}</p>
            </div>
          </div>

          <div class="silde_right">
            <div class="food_info">
              <p>{{ food_info_breakfast }}</p>
            </div>
          </div>
        </div>

        <div v-show="this.time === this.lunch" class="food_slide_lunch">
          <div class="silde_left">
            <div class="food_image">
              <img :src="food_img_lunch" />
            </div>
            <div class="food_name">
              <p>{{ food_name_lunch }}</p>
            </div>
          </div>
          <div class="silde_right">
            <div class="food_info">
              <p>{{ food_info_lunch }}</p>
            </div>
          </div>
        </div>

        <div v-show="this.time === this.dinner" class="food_slide_dinner">
          <div class="silde_left">
            <div class="food_image">
              <img :src="food_img_dinner" />
            </div>
            <div class="food_name">
              <p>{{ food_name_dinner }}</p>
            </div>
          </div>
          <div class="silde_right">
            <div class="food_info">
              <p>{{ food_info_dinner }}</p>
            </div>
          </div>
        </div>
      </div>

      <div class="food_btn">
        <button
          class="food_breakfast"
          @click="SetTime(this.breakfast)"
          :class="{ active: time === breakfast }"
        >
          <div class="img_morning"></div>
          아침
        </button>
        <button class="food_lunch" @click="SetTime(this.lunch)" :class="{ active: time === lunch }">
          <div class="img_lunch"></div>
          점심
        </button>
        <button
          class="food_dinner"
          @click="SetTime(this.dinner)"
          :class="{ active: time === dinner }"
        >
          <div class="img_dinner"></div>
          저녁
        </button>
      </div>
    </div>
  </div>
</template>
<script>
import db from '../assets/test_db2.json'
import axios from 'axios'

export default {
  name: 'app',
  data: () => ({
    username: db[6].username,
    time: null,
    breakfast: 3,
    lunch: 4,
    dinner: 5,
    food_img_breakfast: '',
    food_name_breakfast: '',
    food_info_breakfast: '',
    food_img_lunch: '',
    food_name_lunch: '',
    food_info_lunch: '',
    food_img_dinner: '',
    food_name_dinner: '',
    food_info_dinner: '',
    videoarr: []
  }),
  methods: {
    getinfo() {
      axios
        .get('https:///kgubsh.loca.lt/api/diets/')
        .then((response) => {
          this.videoarr = response.data
          this.updateDB()
        })
        .catch((err) => {
          console.log(err)
        })
    },
    getimgs() {
      // '근력운동' 카테고리 필터링
      const strengthTrainingVideos = this.videoarr.filter((video) => video.diet_type === '다이어트')
      console.log('Filtered strength training videos:', strengthTrainingVideos) // 디버깅 로그

      // 랜덤하게 3개의 이미지 선택
      const randomVideos = this.getRandomElements(strengthTrainingVideos, 3)
      console.log('Random videos selected:', randomVideos) // 디버깅 로그

      return randomVideos
    },
    getRandomElements(arr, count) {
      const shuffled = arr.slice(0)
      let i = arr.length
      let temp, index
      while (i--) {
        index = Math.floor(Math.random() * (i + 1))
        temp = shuffled[index]
        shuffled[index] = shuffled[i]
        shuffled[i] = temp
      }
      return shuffled.slice(0, count)
    },
    SetDefaultTime() {
      var CurrentDate = new Date()
      if (5 <= CurrentDate.getHours() && CurrentDate.getHours() <= 10) {
        return this.breakfast
      } else if (11 <= CurrentDate.getHours() && CurrentDate.getHours() <= 16) {
        return this.lunch
      } else {
        return this.dinner
      }
    },
    SetTime(index) {
      this.time = index
    },
    updateDB() {
      const randomVideos = this.getimgs() // getimgs 호출하여 랜덤한 비디오 가져옴

      if (randomVideos.length > 0) {
        this.food_img_breakfast = randomVideos[0].img
        this.food_name_breakfast = randomVideos[0].name
        this.food_info_breakfast = randomVideos[0].comment
      }
      if (randomVideos.length > 1) {
        this.food_img_lunch = randomVideos[1].img
        this.food_name_lunch = randomVideos[1].name
        this.food_info_lunch = randomVideos[1].comment
      }
      if (randomVideos.length > 2) {
        this.food_img_dinner = randomVideos[2].img
        this.food_name_dinner = randomVideos[2].name
        this.food_info_dinner = randomVideos[2].comment
      }
    }
  },
  created() {
    document.title = '건강밥상 - PersonalHealth'
    this.time = this.SetDefaultTime()
    this.getinfo()
  }
}
</script>

<style scoped>
@media screen and (max-width: 1280px) {
  #header {
    display: none;
  }
}

.text {
  display: none;
}

.category_change {
  width: fit-content;
  height: fit-content;
  padding: 10px;
  background: #fcfcfc;
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  gap: 2px;
  position: absolute;
  right: 10%;
  top: 45px;
}

.category_change:hover {
  transition: 0.2s linear;
  background: linear-gradient(333.21deg, #42d665 21.8%, #36bdff 78.2%);
  transform: translate(-5%);
  transform: scale(0.95);
}
.category_change:hover > .text {
  display: block;
  font-size: 1.2rem;
  font-weight: 600;
  transition: 0.2s linear;
  color: white;
  font-family: 'Noto Sans KR';
}

.category_change > .imgbox {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='%23575757' d='M12 5c-1.11 0-2 .89-2 2s.89 2 2 2s2-.89 2-2s-.89-2-2-2m10-4v5h-2V4H4v2H2V1h2v2h16V1zm-7 10.26V23h-2v-5h-2v5H9V11.26C6.93 10.17 5.5 8 5.5 5.5V5h2v.5C7.5 8 9.5 10 12 10s4.5-2 4.5-4.5V5h2v.5c0 2.5-1.43 4.67-3.5 5.76'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-size: cover;
  width: 2.2vw;
  max-width: 45px;
  min-width: 35px;
  height: 2.2vw;
  max-height: 45px;
  min-height: 35px;
}

.category_change:hover > .imgbox {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='white' d='M12 5c-1.11 0-2 .89-2 2s.89 2 2 2s2-.89 2-2s-.89-2-2-2m10-4v5h-2V4H4v2H2V1h2v2h16V1zm-7 10.26V23h-2v-5h-2v5H9V11.26C6.93 10.17 5.5 8 5.5 5.5V5h2v.5C7.5 8 9.5 10 12 10s4.5-2 4.5-4.5V5h2v.5c0 2.5-1.43 4.67-3.5 5.76'/%3E%3C/svg%3E");
}

#wrapper {
  position: absolute;
  left: 0;
  top: 0;
  margin: 0 0;
  padding: 0 0;

  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  flex-wrap: nowrap;
  width: 100vw;
}

#header {
  z-index: 3;
}

#navbar {
  margin: 0 0;
  padding: 0 0;
  flex-basis: 16vw;
  min-width: 320px;
  max-width: 480px;
}

.section {
  flex-basis: 84vw;
  flex-grow: 1;
  height: 100vh;
  background-color: #fcfcfc;

  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  gap: clamp(10px, 1.5vw, 30px);
  padding-top: 30px;
}

.food_logo {
  color: white;
  font-size: 2.1rem;
  font-weight: 900;
  font-family: 'Noto Sans KR';
  background: linear-gradient(333.21deg, #42d665 21.8%, #36bdff 78.2%);
  padding: 20px;
  border-radius: 13px;
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
  text-align: center;
}

.food_line {
  margin-top: clamp(10px, 2vh, 25vh);
  background: linear-gradient(333.21deg, #42d665 21.8%, #36bdff 78.2%);
  width: 80%;
  min-width: 320px;
  min-height: 60vh;
  height: fit-content;
  display: flex;
  justify-content: center;
  align-items: center;
}

.food_slide_breakfast {
  background: #fcfcfc;
  width: 100%;
  min-height: 97%;
  height: fit-content;

  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
}

.food_slide_lunch {
  background: #fcfcfc;
  width: 100%;
  min-height: 97%;
  height: fit-content;

  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
}

.food_slide_dinner {
  background: #fcfcfc;
  width: 100%;
  min-height: 97%;
  height: fit-content;

  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
}

.silde_left {
  width: 50%;
  height: 100%;

  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: clamp(15px, 1vw, 25px);
}

.silde_right {
  width: 50%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 0;
}

.food_image > img {
  margin: 0;
  width: 25vw;
  max-width: 400px;
  min-width: 200px;
  height: 30vh;
  border-radius: 13px;
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
}

.food_image > img:hover {
  transform: scale(1.2);
  transition-duration: 0.2s;
  cursor: pointer;
}

.food_name {
  min-width: 12vw;
  width: fit-content;
  height: 10vh;
  background-color: #fcfcfc;
  border-radius: 10px;
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
  padding: 0 10px;

  font-size: 1.5rem;
  font-family: 'Noto Sans KR';
  color: #575757;
  font-weight: 700;

  display: flex;
  justify-content: center;
  align-items: center;
}
.food_name > p {
  font-weight: 700;
}

.food_info {
  width: 85%;
  height: 85%;
  max-width: 450px;
  min-width: 200px;
  min-height: 250px;
  padding: 20px;

  background: #fcfcfc;
  border-radius: 15px;
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
  font-size: clamp(1rem, 1.3vw, 1.3rem);
  font-family: 'Noto Sans KR';
  color: #8a8a8a;
}
.food_info > p {
  font-weight: 500;
}

.food_info:hover {
  transform: scale(1.04);
  transition-duration: 0.1s;
  background: linear-gradient(333.21deg, #42d665 21.8%, #36bdff 78.2%);
  color: white;
  cursor: pointer;
}

.food_btn {
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  gap: 25px;
}

button {
  background: #fcfcfc;
  width: 200px;
  height: 60px;
  border: 0;
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
  border-radius: 12px;

  font-weight: 600;
  font-size: 1.2rem;
  font-family: 'Noto Sans KR';
  color: #575757;

  display: flex;
  justify-content: center;
  align-items: center;
  gap: 20px;
  cursor: pointer;
}

.img_morning {
  width: 40px;
  height: 40px;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 16 16'%3E%3Cpath fill='%23575757' d='m14 10l-1.58-1.18L13.2 7l-2-.23L11 4.8l-1.82.78L8 4L6.82 5.58L5 4.8l-.23 2L2.8 7l.78 1.82L2 10H0v1h16v-1zM4 10a4.143 4.143 0 0 1 3.993-4A4.143 4.143 0 0 1 12 9.993z'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-size: 100%;
}

.img_lunch {
  width: 35px;
  height: 35px;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 256 256'%3E%3Cpath fill='%23575757' d='M120 40V16a8 8 0 0 1 16 0v24a8 8 0 0 1-16 0m8 24a64 64 0 1 0 64 64a64.07 64.07 0 0 0-64-64m-69.66 5.66a8 8 0 0 0 11.32-11.32l-16-16a8 8 0 0 0-11.32 11.32Zm0 116.68l-16 16a8 8 0 0 0 11.32 11.32l16-16a8 8 0 0 0-11.32-11.32M192 72a8 8 0 0 0 5.66-2.34l16-16a8 8 0 0 0-11.32-11.32l-16 16A8 8 0 0 0 192 72m5.66 114.34a8 8 0 0 0-11.32 11.32l16 16a8 8 0 0 0 11.32-11.32ZM48 128a8 8 0 0 0-8-8H16a8 8 0 0 0 0 16h24a8 8 0 0 0 8-8m80 80a8 8 0 0 0-8 8v24a8 8 0 0 0 16 0v-24a8 8 0 0 0-8-8m112-88h-24a8 8 0 0 0 0 16h24a8 8 0 0 0 0-16'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-size: 100%;
}

.img_dinner {
  width: 37px;
  height: 37px;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cg fill='%23575757' fill-opacity='0'%3E%3Cpath d='M15.22 6.03L17.75 4.09L14.56 4L13.5 1L12.44 4L9.25 4.09L11.78 6.03L10.87 9.09L13.5 7.28L16.13 9.09L15.22 6.03Z' fill-opacity='1'/%3E%3Cpath d='M19.61 12.25L21.25 11L19.19 10.95L18.5 9L17.81 10.95L15.75 11L17.39 12.25L16.8 14.23L18.5 13.06L20.2 14.23L19.61 12.25Z' fill-opacity='1'/%3E%3C/g%3E%3Cg fill-opacity='0' stroke='%23575757' stroke-linecap='round' stroke-linejoin='round' stroke-width='2'%3E%3Cpath fill='%23575757' d='M7 6 C7 12.08 11.92 17 18 17 C18.53 17 19.05 16.96 19.56 16.89 C17.95 19.36 15.17 21 12 21 C7.03 21 3 16.97 3 12 C3 8.83 4.64 6.05 7.11 4.44 C7.04 4.95 7 5.47 7 6 Z' fill-opacity='1'/%3E%3C/g%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-size: 100%;
}

.active > .img_morning {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 16 16'%3E%3Cpath fill='white' d='m14 10l-1.58-1.18L13.2 7l-2-.23L11 4.8l-1.82.78L8 4L6.82 5.58L5 4.8l-.23 2L2.8 7l.78 1.82L2 10H0v1h16v-1zM4 10a4.143 4.143 0 0 1 3.993-4A4.143 4.143 0 0 1 12 9.993z'/%3E%3C/svg%3E");
}

.active > .img_lunch {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 256 256'%3E%3Cpath fill='white' d='M120 40V16a8 8 0 0 1 16 0v24a8 8 0 0 1-16 0m8 24a64 64 0 1 0 64 64a64.07 64.07 0 0 0-64-64m-69.66 5.66a8 8 0 0 0 11.32-11.32l-16-16a8 8 0 0 0-11.32 11.32Zm0 116.68l-16 16a8 8 0 0 0 11.32 11.32l16-16a8 8 0 0 0-11.32-11.32M192 72a8 8 0 0 0 5.66-2.34l16-16a8 8 0 0 0-11.32-11.32l-16 16A8 8 0 0 0 192 72m5.66 114.34a8 8 0 0 0-11.32 11.32l16 16a8 8 0 0 0 11.32-11.32ZM48 128a8 8 0 0 0-8-8H16a8 8 0 0 0 0 16h24a8 8 0 0 0 8-8m80 80a8 8 0 0 0-8 8v24a8 8 0 0 0 16 0v-24a8 8 0 0 0-8-8m112-88h-24a8 8 0 0 0 0 16h24a8 8 0 0 0 0-16'/%3E%3C/svg%3E");
}

.active > .img_dinner {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cg fill='white' fill-opacity='0'%3E%3Cpath d='M15.22 6.03L17.75 4.09L14.56 4L13.5 1L12.44 4L9.25 4.09L11.78 6.03L10.87 9.09L13.5 7.28L16.13 9.09L15.22 6.03Z' fill-opacity='1'/%3E%3Cpath d='M19.61 12.25L21.25 11L19.19 10.95L18.5 9L17.81 10.95L15.75 11L17.39 12.25L16.8 14.23L18.5 13.06L20.2 14.23L19.61 12.25Z' fill-opacity='1'/%3E%3C/g%3E%3Cg fill-opacity='0' stroke='white' stroke-linecap='round' stroke-linejoin='round' stroke-width='2'%3E%3Cpath fill='white' d='M7 6 C7 12.08 11.92 17 18 17 C18.53 17 19.05 16.96 19.56 16.89 C17.95 19.36 15.17 21 12 21 C7.03 21 3 16.97 3 12 C3 8.83 4.64 6.05 7.11 4.44 C7.04 4.95 7 5.47 7 6 Z' fill-opacity='1'/%3E%3C/g%3E%3C/svg%3E");
}

.active {
  cursor: pointer;
  transform: scale(0.95);
  background: linear-gradient(333.21deg, #42d665 21.8%, #36bdff 78.2%);
  color: white;
  transition-duration: 0.2s;
}
</style>
