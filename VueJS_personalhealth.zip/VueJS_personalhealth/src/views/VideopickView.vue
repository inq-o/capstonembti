<template>
  <main>
    <div class="logo"><span>참여하고 싶은 운동을 선택하세요!</span></div>

    <div class="info">
      <div class="weight">
        <button
          class="weight_sel"
          @click="toggleweightbtn()"
          :class="{ actbtn: weight_key === true }"
        >
          근력운동
          <img
            v-show="sort_valid_key_w === true"
            src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='%23239414' fill-rule='evenodd' d='M12 21a9 9 0 1 0 0-18a9 9 0 0 0 0 18m-.232-5.36l5-6l-1.536-1.28l-4.3 5.159l-2.225-2.226l-1.414 1.414l3 3l.774.774z' clip-rule='evenodd'/%3E%3C/svg%3E"
          />
        </button>

        <div class="weight_modal" v-show="weight_key">
          <p class="holder">시청하고 싶은 영상을 순서대로 골라주세요!</p>
          <div class="weight_list" v-show="weight_sort.length > 0">
            <p v-for="ind in weight_sort.length" :key="ind">
              {{ ind + '. ' + weight_sort[ind - 1] }}
            </p>
          </div>
          <button
            v-for="index in weight_names.length"
            :key="index"
            v-bind:disabled="weight_btn_key == false"
            :class="{ actived: weight_sort.includes(weight_names[index - 1]) }"
            @click="toggleWeightSort(weight_names[index - 1])"
          >
            <img :src="weight_imgs[index - 1]" height="100%" />
            {{ weight_names[index - 1] }}
          </button>

          <div class="weight_save">
            <button @click="checkweightsort()">저장하기</button>
            <p>{{ sort_valid_text_w }}</p>
          </div>
        </div>
      </div>

      <div class="cardio">
        <button
          class="cardio_sel"
          @click="togglecardiobtn()"
          :class="{ actbtn: cardio_key === true }"
        >
          유산소운동
          <img
            v-show="sort_valid_key_c === true"
            src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1em' height='1em' viewBox='0 0 24 24'%3E%3Cpath fill='%23239414' fill-rule='evenodd' d='M12 21a9 9 0 1 0 0-18a9 9 0 0 0 0 18m-.232-5.36l5-6l-1.536-1.28l-4.3 5.159l-2.225-2.226l-1.414 1.414l3 3l.774.774z' clip-rule='evenodd'/%3E%3C/svg%3E"
          />
        </button>

        <div class="cardio_modal" v-show="cardio_key">
          <p class="holder">시청하고 싶은 영상을 순서대로 골라주세요!</p>
          <div class="cardio_list" v-show="cardio_sort.length > 0">
            <p v-for="ind in cardio_sort.length" :key="ind">
              {{ ind + '. ' + cardio_sort[ind - 1] }}
            </p>
          </div>
          <button
            v-for="index in cardio_names.length"
            :key="index"
            v-bind:disabled="cardio_btn_key == false"
            :class="{ actived: cardio_sort.includes(cardio_names[index - 1]) }"
            @click="toggleCardioSort(cardio_names[index - 1])"
          >
            <img :src="cardio_imgs[index - 1]" height="100%" />
            {{ cardio_names[index - 1] }}
          </button>

          <div class="cardio_save">
            <button @click="checkcardiosort()">저장하기</button>
            <p>{{ sort_valid_text_c }}</p>
          </div>
        </div>
      </div>

      <button
        v-show="weight_btn_key === false && cardio_btn_key === false"
        class="btn_submit"
        @click="videopick_submit()"
      >
        제출하기
      </button>
    </div>
  </main>
</template>

<script>
import axios from 'axios'
import db from '../assets/test_db2.json'

export default {
  data() {
    return {
      weight_key: false,
      cardio_key: false,

      weight_names: [],
      weight_imgs: [],
      weight_vid: [],
      weight_sort: [],
      weight_sort_num: [],
      weight_btn_key: true,

      cardio_names: [],
      cardio_imgs: [],
      cardio_vid: [],
      cardio_sort: [],
      cardio_sort_num: [],
      cardio_btn_key: true,

      sort_valid_key_w: false,
      sort_valid_key_c: false,
      sort_valid_text_w: '',
      sort_valid_text_c: ''
    }
  },
  methods: {
    toggleweightbtn() {
      if (this.weight_key == false) {
        this.weight_key = true
        this.cardio_key = false
      } else if (this.weight_key == true) {
        this.weight_key = false
      }
    },
    togglecardiobtn() {
      if (this.cardio_key == false) {
        this.cardio_key = true
        this.weight_key = false
      } else if (this.cardio_key == true) {
        this.cardio_key = false
      }
    },

    toggleWeightSort(name) {
      const index = this.weight_sort.indexOf(name)
      if (index === -1) {
        this.weight_sort.push(name)
      } else {
        this.weight_sort.splice(index, 1)
      }
    },
    checkweightsort() {
      this.sort_valid_key_w = this.weight_names.every((name) => this.weight_sort.includes(name))
      if (this.sort_valid_key_w == true) {
        this.sort_valid_text_w = '저장에 성공했습니다.'
        this.weight_number()
        this.weight_btn_blocker()
      } else {
        this.sort_valid_text_w = '저장에 실패했습니다. 전부 선택해주세요'
      }
    },
    weight_number() {
      for (var i = 0; i < this.weight_sort.length; i++) {
        this.weight_sort_num[i] = [i] + this.weight_sort[i]
      }
    },
    weight_btn_blocker() {
      this.weight_btn_key = false
    },
    toggleCardioSort(name_c) {
      const index = this.cardio_sort.indexOf(name_c)
      if (index === -1) {
        this.cardio_sort.push(name_c)
      } else {
        this.cardio_sort.splice(index, 1)
      }
    },
    checkcardiosort() {
      this.sort_valid_key_c = this.cardio_names.every((name_c) => this.cardio_sort.includes(name_c))
      if (this.sort_valid_key_c == true) {
        this.sort_valid_text_c = '저장에 성공했습니다.'
        this.cardio_number()
        this.cardio_btn_blocker()
      } else {
        this.sort_valid_text_c = '저장에 실패했습니다. 전부 선택해주세요'
      }
    },
    cardio_number() {
      for (var i = 0; i < this.cardio_sort.length; i++) {
        this.cardio_sort_num[i] = [i] + this.cardio_sort[i]
      }
    },
    cardio_btn_blocker() {
      this.cardio_btn_key = false
    },
    videopick_submit() {
      // 선택한 영상 정보를 서버로 전송하여 ViewHistory 생성

      axios
        .post('hhttps://kgubsh.loca.lt/update_view_score', {
          user_id: this.user_id,
          video_id: this.selected_video_id,
          start_time: this.start_time,
          end_time: this.end_time
        })
        .then((response) => {
          alert('제출 되었습니다!')
          this.$router.push('/weight')
        })
        .catch((error) => {
          console.error('Error submitting video pick:', error)
        })
    },

    getvideo() {
      axios
        .get('https://kgubsh.loca.lt/api/videos/')
        .then((response) => {
          this.videoarr = response.data
          this.weightvid()
          this.weightname()
          this.weightimg()
          this.cardioimg()
          this.cardiovid()
          this.cardioname()
        })
        .catch((err) => {
          console.log(err)
        })
    },
    weightvid() {
      this.weight_vid = this.videoarr
        .filter((video) => video.category === '근력운동') // '근력운동' 카테고리 필터링
        .map((video) => video.videoid) // 슬라이드 URL만 추출
    },
    weightname() {
      this.weight_names = this.videoarr
        .filter((video) => video.category === '근력운동') // '근력운동' 카테고리 필터링
        .map((video) => video.title) // 슬라이드 URL만 추출
    },
    weightimg() {
      this.weight_imgs = this.videoarr
        .filter((video) => video.category === '근력운동') // '근력운동' 카테고리 필터링
        .map((video) => video.slides) // 슬라이드 URL만 추출
    },
    cardiovid() {
      this.cardio_vid = this.videoarr
        .filter((video) => video.category === '다이어트') // '근력운동' 카테고리 필터링
        .map((video) => video.videoid) // 슬라이드 URL만 추출
    },
    cardioname() {
      this.cardio_names = this.videoarr
        .filter((video) => video.category === '다이어트') // '근력운동' 카테고리 필터링
        .map((video) => video.title) // 슬라이드 URL만 추출
    },
    cardioimg() {
      this.cardio_imgs = this.videoarr
        .filter((video) => video.category === '다이어트') // '근력운동' 카테고리 필터링
        .map((video) => video.slides) // 슬라이드 URL만 추출
    }
  },
  created() {
    document.title = '참여하고 싶은 운동을 선택하세요!'
  },
  mounted() {
    this.getvideo()
  }
}
</script>

<style scoped>
.holder {
  font-size: 1.2rem;
  font-weight: 600;
  font-family: 'Noto Sans KR';
  color: #888888;
}
.btn_submit {
  border: none;
  background: linear-gradient(333.21deg, #42d665 21.8%, #36bdff 78.2%);
  font-size: 20px;
  font-weight: 700;
  font-family: 'Noto Sans KR';
  color: white;
  padding: 10px 40px;
  border-radius: 10px;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-color: transparent;
}

.btn_submit:hover {
  background: #575757;
  cursor: pointer;
  transform: scale(0.95);
  transition-duration: 0.2s;
}

.weight_list {
  background: #fcfcfc;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  padding: 30px 80px;
  border-radius: 13px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  gap: 5px;
  color: #575757;
  font-size: 1.1rem;
}

.weight_list > p {
  font-weight: 700;
  font-family: 'Noto Sans KR';
}

.weight_list:hover {
  background: linear-gradient(295.45deg, #36b2ff 11.41%, #42d665 88.59%);
  color: white;
  transform: scale(1.1);
  transition-duration: 0.2s;
  z-index: 5;
}

.weight > .actbtn {
  opacity: 0.6;
  transition-duration: 0.2s;
  transform: scale(0.97);
}

.weight > button:hover {
  transition-duration: 0.2s;
  transform: scale(0.97);
  opacity: 0.6;
}

.cardio > .actbtn {
  opacity: 0.6;
  transition-duration: 0.2s;
  transform: scale(0.97);
}

.cardio > button:hover {
  transition-duration: 0.2s;
  transform: scale(0.97);
  opacity: 0.6;
}

.weight_modal {
  transition-duration: 0.2s;

  width: 80%;
  height: fit-content;
  padding: 30px 0;

  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 25px;
}

.weight_modal > button {
  width: 100%;
  height: 140px;
  border: none;
  background: #fcfcfc;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 13px;
  cursor: pointer;
  padding-left: 0;
  padding-top: 0;
  padding-bottom: 0;
  padding-right: 1rem;

  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  gap: 9%;

  font-size: clamp(0.9rem, 1.5vw, 1.25rem);
  font-weight: 700;
  font-family: 'Noto Sans KR';
  color: #575757;
}

.weight_modal > button > img {
  border-top-left-radius: 13px;
  border-bottom-left-radius: 13px;
  width: 150px;
}

.cardio_list {
  background: #fcfcfc;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  padding: 30px 80px;
  border-radius: 13px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  gap: 5px;
  color: #575757;
  font-size: 1.1rem;
}

.cardio_list > p {
  font-weight: 700;
  font-family: 'Noto Sans KR';
}

.cardio_list:hover {
  background: linear-gradient(295.45deg, #36b2ff 11.41%, #42d665 88.59%);
  color: white;
  transform: scale(1.1);
  transition-duration: 0.2s;
  z-index: 5;
}

.cardio_modal {
  transition-duration: 0.2s;

  width: 80%;
  height: fit-content;
  padding: 30px 0;

  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 25px;
}

.cardio_modal > button {
  width: 100%;
  height: 140px;
  border: none;
  background: #fcfcfc;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 13px;
  cursor: pointer;
  padding-left: 0;
  padding-top: 0;
  padding-bottom: 0;
  padding-right: 1rem;

  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  gap: 9%;

  font-size: clamp(0.9rem, 1.5vw, 1.25rem);
  font-weight: 700;
  font-family: 'Noto Sans KR';
  color: #575757;
}

.cardio_modal > button > img {
  border-top-left-radius: 13px;
  border-bottom-left-radius: 13px;
  width: 150px;
}

main {
  overflow: hidden;
  position: absolute;
  left: 0;
  top: 0;
  width: 100%;
  min-height: 100vh;
  background: linear-gradient(295.45deg, #36b2ff 11.41%, #42d665 88.59%);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  transition-duration: 0.2s;
}

.logo {
  margin-top: 50px;
  background: linear-gradient(295.45deg, #36b2ff 11.41%, #42d665 88.59%);
  padding: 15px 20px;
  border-radius: 15px;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  display: flex;
  justify-content: center;
  align-items: center;
}

.logo > span {
  color: white;
  font-family: 'Noto Sans KR';
  font-size: 25px;
  font-style: normal;
  font-weight: 900;
  transform: rotate(0.04deg);
}

.info {
  position: relative;
  margin-top: 50px;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  border-radius: 25px;
  max-width: 960px;
  width: 50vw;
  min-width: 400px;
  height: fit-content;
  background-color: #fcfcfc;
  margin-bottom: 100px;

  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding-top: 20px;
  padding-bottom: 20px;
  gap: 30px;
  transition-duration: 0.2s;
}

.weight {
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.weight > button {
  width: 97%;
  height: 180px;
  border-radius: 15px;
  background-image: url('https://59.18.172.95/www/backimg/weight_train.jpg');
  background-size: cover;
  background-position: 70%;
  border: 0;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  cursor: pointer;

  font-size: 1.8rem;
  color: white;
  font-weight: 900;
  font-family: 'Noto Sans KR';

  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  gap: 1rem;
}

.weight > button > img {
  width: 55px;
  height: 55px;
  transition-duration: 0.2s;
}

.cardio {
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.cardio > button {
  width: 97%;
  height: 180px;
  border-radius: 15px;
  background-image: url('https://59.18.172.95/www/backimg/running.jpg');
  background-size: cover;
  background-position: 0px 310px;
  border: 0;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  cursor: pointer;

  font-size: 1.8rem;
  color: white;
  font-weight: 900;
  font-family: 'Noto Sans KR';

  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  gap: 1rem;
}

.cardio > button > img {
  width: 55px;
  height: 55px;
  transition-duration: 0.2s;
}

.weight_modal > .actived {
  background: linear-gradient(295.45deg, #36b2ff 11.41%, #42d665 88.59%);
  color: white;
  transform: scale(0.98);
}

.weight_modal > button:hover {
  background: linear-gradient(295.45deg, #36b2ff 11.41%, #42d665 88.59%);
  color: white;
  transform: scale(0.98);
  transition-duration: 0.2s;
}

.weight_save {
  margin-top: 10px;
  width: 50%;

  display: flex;
  flex-direction: column;
  justify-content: center;
  align-self: center;
  gap: 10px;
}

.weight_save > button {
  background: linear-gradient(295.45deg, #36b2ff 11.41%, #42d665 88.59%);
  border: none;
  padding: 10px;
  font-size: 1.17rem;
  font-weight: 900;
  font-family: 'Noto Sans KR';
  color: white;
  border-radius: 10px;
  cursor: pointer;
}

.weight_save > button:hover {
  background: #575757;
  transform: scale(0.93);
  transition-duration: 0.2s;
}

.weight_save > p {
  font-size: 1rem;
  font-family: 'Noto Sans KR';
  font-weight: 600;
  color: #575757;
  text-align: center;
}

.cardio_modal > .actived {
  background: linear-gradient(295.45deg, #36b2ff 11.41%, #42d665 88.59%);
  color: white;
  transform: scale(0.98);
}

.cardio_modal > button:hover {
  background: linear-gradient(295.45deg, #36b2ff 11.41%, #42d665 88.59%);
  color: white;
  transform: scale(0.98);
  transition-duration: 0.2s;
}

.cardio_save {
  margin-top: 10px;
  width: 50%;

  display: flex;
  flex-direction: column;
  justify-content: center;
  align-self: center;
  gap: 10px;
}

.cardio_save > button {
  background: linear-gradient(295.45deg, #36b2ff 11.41%, #42d665 88.59%);
  border: none;
  padding: 10px;
  font-size: 1.17rem;
  font-weight: 900;
  font-family: 'Noto Sans KR';
  color: white;
  border-radius: 10px;
  cursor: pointer;
}

.cardio_save > button:hover {
  background: #575757;
  transform: scale(0.93);
  transition-duration: 0.2s;
}

.cardio_save > p {
  font-size: 1rem;
  font-family: 'Noto Sans KR';
  font-weight: 600;
  color: #575757;
  text-align: center;
}
</style>
