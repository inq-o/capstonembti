<script setup>
import NavBar from '../components/NavBar.vue'
</script>

<template>
  <div id="wrapper">
    <div id="header">
      <NavBar :username="username"> </NavBar>
    </div>
    <div class="section">
      <carousel
        :slides="slides"
        :names="names"
        :links="links"
        :publishers="publishers"
        :category="categorys"
        :interval="5000"
        indicators
      ></carousel>
    </div>
  </div>
</template>

<script>
import Carousel from '../components/carousel/Carousel.vue'
import db from '../assets/test_db2.json'
import axios from 'axios'

export default {
  name: 'App',
  components: { Carousel },
  data: () => ({
    slides: [],
    names: [],
    links: [],
    username: db[6].username,
    publishers: [],
    categorys: [],
    videoarr: [],
    videoid: [],
    videoidToSlides: {}
  }),
  methods: {
    getinfo() {
      axios
        .get('https://kgubsh.loca.lt/api/videos/')
        .then((response) => {
          this.videoarr = response.data
          this.getslides()
          this.getnames()
          this.getpub()
          this.getlink()
          this.getcategory()
        })
        .catch((err) => {
          console.log(err)
        })
    },
    getslides() {
      this.slides = this.videoarr
        .filter((video) => video.category === '다이어트') // '근력운동' 카테고리 필터링
        .map((video) => video.slides) // 슬라이드 URL만 추출
    },
    getnames() {
      this.names = this.videoarr
        .filter((video) => video.category === '다이어트') // '근력운동' 카테고리 필터링
        .map((video) => video.title) // 슬라이드 URL만 추출
    },
    getpub() {
      this.publishers = this.videoarr
        .filter((video) => video.category === '다이어트') // '근력운동' 카테고리 필터링
        .map((video) => video.publishers) // 슬라이드 URL만 추출
    },
    getlink() {
      this.links = this.videoarr
        .filter((video) => video.category === '다이어트') // '근력운동' 카테고리 필터링
        .map((video) => video.url) // 슬라이드 URL만 추출
    },
    getcategory() {
      this.categorys = this.videoarr
        .filter((video) => video.category === '다이어트') // '근력운동' 카테고리 필터링
        .map((video) => video.category) // 슬라이드 URL만 추출
    }
  },
  created() {
    document.title = '유산소운동 - PersonalHealth'
  },
  mounted() {
    this.getinfo()
  }
}
</script>

<style scoped>
@media screen and (max-width: 640px) {
  #header {
    display: none;
  }
}

#wrapper {
  position: absolute;
  left: 0;
  top: 0;
  margin: 0 0;
  padding: 0 0;

  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  flex-wrap: nowrap;
  width: 100vw;
}

#header {
  z-index: 3;
}

#navbar {
  margin: 0 0;
  padding: 0 0;
  flex-basis: 16vw;
  min-width: 320px;
  max-width: 480px;
}

.section {
  flex-basis: 84vw;
  flex-grow: 1;
  height: 100vh;
}
</style>
