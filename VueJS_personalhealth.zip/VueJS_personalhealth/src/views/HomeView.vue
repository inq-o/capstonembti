<template>
  <main>
    <div id="logo">PersonalHealth</div>
    <div id="article">
      <div id="phrasewrap">
        <div id="phrase01">완전히 새로워진 홈트레이닝,</div>
        <div id="phrase02">함께 할 준비 되셨나요?</div>
      </div>

      <RouterLink to="/login" id="joinus"><p>홈트레이닝 시작하기!</p></RouterLink>
    </div>
    <div class="footer">KGU 2024 Pre Capstone Design</div>
  </main>
</template>

<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>
<script>
export default {
  name: 'app',
  created() {
    document.title = 'PersonalHealth에 오신 것을 환영합니다 !'
  }
}
</script>

<style scoped>
main {
  overflow: hidden;
  position: absolute;
  left: 0;
  top: 0;
  width: 100vw;
  height: 100vh;
  background: linear-gradient(295.45deg, #36b2ff 11.41%, #42d665 88.59%);
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
}
#article {
  position: relative;
  min-width: 960px;
  max-width: 1280px;
  margin: 0 auto;
  min-height: 540px;
  height: 70%;
  max-height: 720px;
}

#phrasewrap {
  position: absolute;
  top: 30%;
  left: 10%;
  width: 600px;
  height: fit-content;
}

#phrase01 {
  color: white;
  font-size: 45px;
  font-weight: 500;
  font-family: 'Noto Sans KR';
}

#phrase02 {
  color: white;
  font-size: 55px;
  font-weight: 900;
  font-family: 'Noto Sans KR';
}

#joinus {
  background-color: #2560f9;
  border-radius: 50px;
  width: 296px;
  height: 55px;
  padding: 15px;

  position: absolute;
  bottom: 20px;
  right: 20px;
}

#joinus:hover {
  transform: scale(1.1);
  transition: 0.1s linear;
}

#joinus > p {
  text-align: center;
  font-size: 1rem;
  font-family: 'Noto Sans KR';
  font-weight: 900;
  color: white;
}

#logo {
  position: absolute;
  top: 25px;
  left: 8vw;
  color: white;
  font-size: 20px;
  font-style: normal;
  font-weight: 900;
  font-family: 'Noto Sans KR';
  margin-top: 25px;
  margin-bottom: 20px;
}

a {
  text-decoration-line: none;
}

a:hover {
  text-decoration-line: none;
}

.footer {
  color: white;
  font-family: 'Noto Sans KR';
  font-weight: 600;
  font-size: 1rem;
  position: absolute;
  bottom: 50px;
}
</style>
