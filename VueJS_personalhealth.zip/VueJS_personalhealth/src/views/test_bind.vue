<template>
  <div>
    <p>test</p>
    <ul>
      <li v-for="diet in diets" :key="diet.diet_id">{{ diet.name }} ({{ diet.diet_type }})</li>
    </ul>
    <br />

    <ul>
      <li v-for="video in videos" :key="video.video_id">
        <img :src="video.slides" width="100px" height="100px" />
        {{ video.videoid }} {{ video.title }} {{ video.category }} {{ video.publishers }}
      </li>
    </ul>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      diets: [], // 데이터를 저장할 배열
      videos: []
    }
  },
  methods: {
    imgget() {
      axios
        .get('https://smooth-schools-jog.loca.lt/api/diets/?format=json')
        .then((response) => {
          this.diets = response.data // 데이터를 this.diets에 저장
        })
        .catch((err) => {
          console.log(err)
        })
    },
    videoget() {
      axios
        .get('https://smooth-schools-jog.loca.lt/api/videos/?format=json')
        .then((response) => {
          this.videos = response.data // 데이터를 this.diets에 저장
        })
        .catch((err) => {
          console.log(err)
        })
    }
  },
  created() {
    this.imgget() // 컴포넌트가 생성될 때 데이터를 가져옴
    this.videoget()
  }
}
</script>

<style scoped>
/* 필요한 스타일 추가 */
</style>
