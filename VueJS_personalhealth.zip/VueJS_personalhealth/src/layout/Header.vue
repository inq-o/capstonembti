<template>
    <div id="box">
        <NavBar></NavBar>
    </div>
</template>

<script setup>
import NavBar from './components/NavBar.vue';

</script>

<style scoped>
#box {
    position: absolute;
    left:0;
    top:0;
    width:98vw;
    height:70px;
    margin: 0 auto;
}

</style>